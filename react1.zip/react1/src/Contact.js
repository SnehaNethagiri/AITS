const Contact=() => {
    return <h1>Contact me</h1>;
};
export default Contact;

